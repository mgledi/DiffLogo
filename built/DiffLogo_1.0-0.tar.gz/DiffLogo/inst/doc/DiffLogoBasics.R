## ----ImportLibrary-------------------------------------------------------
library(DiffLogo)

## ----ImportPWMs----------------------------------------------------------
## import PWMs
motif_folder = "pwm"
motif_names = c("HepG2","MCF7","HUVEC","ProgFib")
motifs = list()
for (name in motif_names) {
  fileName = paste(motif_folder,"/",name,".txt",sep="")
  file = system.file(fileName, package = "DiffLogo")
  motifs[[name]] = as.matrix(read.delim(file,header=F))
}

## ----PlotSequenceLogo----------------------------------------------------
## plot classic sequence logo
pwm1 = motifs[[motif_names[[1]]]]
pwm2 = motifs[[motif_names[[2]]]]

par(mfrow=c(1,2), pin=c(3, 1))
seqLogo(pwm = pwm1)
seqLogo(pwm = pwm2)

## ----PlotDiffLogo--------------------------------------------------------
## plot DiffLogo
diffLogoFromPwm(pwm1 = pwm1, pwm2 = pwm2)

## diffLogoFromPwm is a convenience function for
diffLogoObj = createDiffLogoObject(pwm1 = pwm1, pwm2 = pwm2)
diffLogo(diffLogoObj)

## ----PlotDiffLogoTable---------------------------------------------------
## plot DiffLogo table
diffLogoTable(motifs)

## ----Export--------------------------------------------------------------
## parameters
widthToHeightRatio = 16/10;
size = length(motifs) * 2
resolution <- 300
width <- size * widthToHeightRatio
height <- size

## export single DiffLogo as pdf document
fileName <- "Comparison_of_two_motifs.pdf"
pdf(file = fileName, width = width, height = height)
diffLogoFromPwm(pwm1 = pwm1, pwm2 = pwm2)
dev.off()

## export DiffLogo table as png image
fileName <- "Comparison_of_multiple_motifs.png"
png(
  filename = fileName, res = resolution,
  width = width * resolution, height = height * resolution)
diffLogoTable(PWMs = motifs)
dev.off()

